#include <iostream>
using namespace std;
int main() {
    cout << "Let's go!" << endl;
    return 0;
}
